def classFactory(iface):
    from .cadgis_main import CadgisSearchPlugin
    return CadgisSearchPlugin(iface)