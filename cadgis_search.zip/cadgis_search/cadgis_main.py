# -*- coding: utf-8 -*-
import sys
import os
import csv
import base64

from qgis.PyQt.QtWidgets import (QAction, QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, 
                                 QLabel, QComboBox, QLineEdit, QPushButton, QTableWidget, 
                                 QTableWidgetItem, QHeaderView, QAbstractItemView, QDialog, 
                                 QFormLayout, QFrame, QMessageBox, QFileDialog)
from qgis.PyQt.QtCore import Qt, QSize
from qgis.PyQt.QtGui import QIcon, QPixmap

from qgis.core import (QgsProject, QgsVectorLayer, QgsFeature, QgsVectorFileWriter, QgsSettings, QgsGeometry, QgsFeatureRequest)
from qgis.utils import iface

# ==============================================================================
# 🎨 1. ICONS MANAGER (BOOTSTRAP SVG EMBEDDED)
# ==============================================================================
class Icons:
    @staticmethod
    def get(name):
        svg_map = {
            "app_logo": """<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#0d6efd" class="bi bi-buildings-fill" viewBox="0 0 16 16"><path d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 5v5H2.5a.5.5 0 0 0-.5.5v5a.5.5 0 0 0 .5.5h6a.5.5 0 0 0 .5-.5V9.342a.5.5 0 0 0 .327-.04l6-3a.5.5 0 0 0 .173-.418V.5ZM2.5 11h3V15h-3v-4Zm5 4V9.613l2-1V15H7.5Zm2.5-10.847L5.854 6.308 10 4.155v.001l4-2V14l-4 2V4.153ZM13 5.613v7.774l-2-1V4.613l2 1Z"/></svg>""",
            "search": """<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-search" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/></svg>""",
            "settings": """<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#495057" class="bi bi-gear-fill" viewBox="0 0 16 16"><path d="M9.405 1.05c-.413-1.4-2.397-1.4-2.81 0l-.1.34a1.464 1.464 0 0 1-2.105.872l-.31-.17c-1.283-.698-2.686.705-1.987 1.987l.169.311c.446.82.023 1.841-.872 2.105l-.34.1c-1.4.413-1.4 2.397 0 2.81l.34.1a1.464 1.464 0 0 1 .872 2.105l-.17.31c-.698 1.283.705 2.686 1.987 1.987l.311-.169a1.464 1.464 0 0 1 2.105.872l.1.34c.413 1.4 2.397 1.4 2.81 0l.1-.34a1.464 1.464 0 0 1 2.105-.872l.31.17c1.283.698 2.686-.705 1.987-1.987l-.169-.311a1.464 1.464 0 0 1 .872-2.105l.34-.1c1.4-.413 1.4-2.397 0-2.81l-.34-.1a1.464 1.464 0 0 1-.872-2.105l.17-.31c.698-1.283-.705-2.686-1.987-1.987l-.311.169a1.464 1.464 0 0 1-2.105-.872l-.1-.34zM8 10.93a2.929 2.929 0 1 1 0-5.86 2.929 2.929 0 0 1 0 5.858z"/></svg>""",
            "csv": """<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#198754" class="bi bi-file-earmark-spreadsheet" viewBox="0 0 16 16"><path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z"/><path d="M3 9h10v1H3v-1zm0 2h10v1H3v-1z"/></svg>""",
            "dxf": """<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#fd7e14" class="bi bi-file-earmark-code" viewBox="0 0 16 16"><path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5h-2z"/><path d="M8.646 6.646a.5.5 0 0 1 .708 0l2 2a.5.5 0 0 1 0 .708l-2 2a.5.5 0 0 1-.708-.708L10.293 9 8.646 7.354a.5.5 0 0 1 0-.708zm-1.292 0a.5.5 0 0 0-.708 0l-2 2a.5.5 0 0 0 0 .708l2 2a.5.5 0 0 0 .708-.708L5.707 9l1.647-1.646a.5.5 0 0 0 0-.708z"/></svg>""",
            "pdf": """<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#dc3545" class="bi bi-file-earmark-pdf" viewBox="0 0 16 16"><path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z"/><path d="M4.603 14.087a.81.81 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.68 7.68 0 0 1 3.798-1.803 15.29 15.29 0 0 0 2.293-1.292c.311-.18.59-.448.775-.781a1 1 0 0 1 .407-.411c.15-.082.381-.138.594-.125.243.015.407.142.456.288.07.207.035.53-.146.919a7.31 7.31 0 0 1-1.262 1.696c-.602.637-1.258 1.148-1.921 1.57a9.12 9.12 0 0 1-2.482 1.334c-.271.74-.53 1.583-.773 2.193a.98.98 0 0 1-.363.47c-.201.127-.557.184-.813.064zM6.9 11.23c.278-.293.535-.615.76-.957a14.74 14.74 0 0 1-2.148 1.777c.367-.32.706-.605.992-.82h.396zm-1.126 1.986c-.166.425-.262.775-.24 1.01.03.32.228.434.39.426.155-.008.267-.13.313-.254.067-.183.05-.443-.058-.87a9.23 9.23 0 0 0-.405-1.312zm4.333-7.3c-.172-.04-.377.017-.5.127-.087.078-.172.185-.243.32-.132.253-.163.633.09 1.132.193.376.53.64.847.665.234.018.528-.15.656-.475.14-.356.035-.865-.303-1.393-.243-.38-.558-.557-.803-.593l.256.217zm1.666 5.567c.338.397.753.684 1.107.828.324.13.59.088.705-.05.105-.125.088-.38-.024-.746a5.07 5.07 0 0 0-.903-1.398c-.378-.444-.817-.893-1.3-1.294.195 1.05.297 1.956.415 2.66z"/></svg>"""
        }
        pixmap = QPixmap()
        if name in svg_map:
            pixmap.loadFromData(bytearray(svg_map[name], 'utf-8'), "svg")
        return QIcon(pixmap)

# ==============================================================================
# 🎨 2. STYLE SHEET
# ==============================================================================
MODERN_STYLE = """
    QWidget { font-family: 'Segoe UI', sans-serif; font-size: 12px; color: #212529; background-color: #ffffff; }
    QLineEdit, QComboBox { background-color: #ffffff; border: 1px solid #ced4da; border-radius: 4px; padding: 4px 8px; color: #495057; min-height: 22px; }
    QLineEdit:focus, QComboBox:focus { border: 1px solid #0d6efd; }
    QPushButton#BtnPrimary { background-color: #0d6efd; color: white; border: none; border-radius: 4px; padding: 5px 15px; font-weight: 600; }
    QPushButton#BtnPrimary:hover { background-color: #0b5ed7; }
    QPushButton#BtnGhost { background-color: transparent; color: #6c757d; border: 1px solid #dee2e6; border-radius: 4px; padding: 5px 10px; }
    QPushButton#BtnGhost:hover { background-color: #f8f9fa; color: #212529; }
    QTableWidget { border: 1px solid #dee2e6; gridline-color: transparent; }
    QHeaderView::section { background-color: #ffffff; border-bottom: 2px solid #dee2e6; font-weight: bold; }
    QFrame#Card { background-color: #ffffff; border: 1px solid #dee2e6; border-radius: 8px; }
    QLabel.Header { font-size: 14px; font-weight: bold; color: #343a40; margin-bottom: 5px; }
    QLabel.SubLabel { font-size: 11px; font-weight: 600; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; }
    QLabel.Value { font-size: 13px; font-weight: bold; color: #212529; }
"""

# ==============================================================================
# CLASS 3: CONFIGURATION DIALOG
# ==============================================================================
class CadgisConfigDialog(QDialog):
    def __init__(self, parent=None):
        super(CadgisConfigDialog, self).__init__(parent)
        self.setWindowTitle("Configuration")
        self.resize(450, 480)
        self.setStyleSheet(MODERN_STYLE)
        
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        
        card = QFrame(); card.setObjectName("Card")
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(15)
        card_layout.setContentsMargins(20, 20, 20, 20)

        # Header
        h_box = QHBoxLayout()
        icon_lbl = QLabel(); icon_lbl.setPixmap(Icons.get("settings").pixmap(24,24))
        title = QLabel("MAPPING & SOURCE"); title.setProperty("class", "Header")
        h_box.addWidget(icon_lbl); h_box.addWidget(title); h_box.addStretch()
        card_layout.addLayout(h_box)

        # 1. Layer Selection
        lbl_layer = QLabel("CHOISIR LA COUCHE (LAYER) :"); lbl_layer.setProperty("class", "SubLabel")
        self.layer_cb = QComboBox()
        self.layer_cb.currentIndexChanged.connect(self.update_fields_list)
        card_layout.addWidget(lbl_layer)
        card_layout.addWidget(self.layer_cb)
        
        line = QFrame(); line.setFrameShape(QFrame.HLine); line.setStyleSheet("color: #dee2e6;")
        card_layout.addWidget(line)

        # 2. Field Mapping
        form_layout = QFormLayout(); form_layout.setSpacing(12)
        self.combos = {}
        self.fields_map = {
            "nature": "Nature (T, R)", "num": "Numéro Parcelle", 
            "indice": "Indice (36, G)", "complement": "Complément", 
            "ref_fonc": "Réf. Foncière", "surf_adop": "Surface"
        }
        
        self.settings = QgsSettings()
        
        for key, label_text in self.fields_map.items():
            lbl = QLabel(label_text); lbl.setProperty("class", "SubLabel")
            cb = QComboBox()
            form_layout.addRow(lbl, cb)
            self.combos[key] = cb
            
        card_layout.addLayout(form_layout)
        main_layout.addWidget(card)
        
        btns = QHBoxLayout(); btns.addStretch()
        btn_cancel = QPushButton("Annuler"); btn_cancel.setProperty("class", "BtnGhost")
        btn_cancel.clicked.connect(self.reject)
        
        btn_save = QPushButton("Enregistrer"); btn_save.setObjectName("BtnPrimary")
        btn_save.clicked.connect(self.save_settings)
        
        btns.addWidget(btn_cancel); btns.addWidget(btn_save)
        main_layout.addLayout(btns)
        self.setLayout(main_layout)
        
        self.populate_layers()

    def populate_layers(self):
        """Populate Combo with current Vector Layers"""
        self.layer_cb.clear()
        self.layers_dict = {}
        for layer in QgsProject.instance().mapLayers().values():
            if layer.type() == QgsVectorLayer.VectorLayer:
                self.layer_cb.addItem(layer.name(), layer.id())
                self.layers_dict[layer.name()] = layer
        
        saved_layer_name = self.settings.value("Cadgis/target_layer_name", "")
        idx = self.layer_cb.findText(saved_layer_name)
        if idx >= 0: self.layer_cb.setCurrentIndex(idx)
        else: self.update_fields_list()

    def update_fields_list(self):
        layer_name = self.layer_cb.currentText()
        if layer_name not in self.layers_dict: return
        
        layer = self.layers_dict[layer_name]
        field_list = sorted([f.name() for f in layer.fields()])
        
        for key, cb in self.combos.items():
            cb.clear()
            cb.addItems([""] + field_list)
            saved_val = self.settings.value(f"Cadgis/fields/{key}", "")
            idx = cb.findText(saved_val)
            if idx >= 0: cb.setCurrentIndex(idx)

    def save_settings(self):
        self.settings.setValue("Cadgis/target_layer_name", self.layer_cb.currentText())
        for key, cb in self.combos.items():
            self.settings.setValue(f"Cadgis/fields/{key}", cb.currentText())
        iface.messageBar().pushMessage("Succès", "Configuration sauvegardée !", level=1)
        self.accept()

# ==============================================================================
# CLASS 4: POPUP INFO
# ==============================================================================
class ParcelInfoDialog(QDialog):
    def __init__(self, feature, layer, parent=None):
        super(ParcelInfoDialog, self).__init__(parent)
        self.feature = feature; self.layer = layer; self.settings = QgsSettings()
        self.setWindowTitle("")
        self.resize(500, 650)
        self.setStyleSheet(MODERN_STYLE)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(15)
        
        # Info Card
        info_card = QFrame(); info_card.setObjectName("Card")
        info_layout = QFormLayout(info_card)
        info_layout.setContentsMargins(20, 20, 20, 20)
        
        f_ref = self.settings.value("Cadgis/fields/ref_fonc", "ref_fonc")
        f_surf = self.settings.value("Cadgis/fields/surf_adop", "surf_adop")
        f_comp = self.settings.value("Cadgis/fields/complement", "complement")
        # 2. قاد القيم (Format Values)
        val_ref = str(feature[f_ref]) if f_ref in feature.fields().names() else "N/A"
        # --- BIDU (START) ---
        raw_surf = feature[f_surf] if f_surf in feature.fields().names() else None
        if raw_surf:
            try:
                # تحويل الرقم لـ Float وتحديد جوج أرقام بعد الفاصلة
                val_surf = f"{float(raw_surf):.2f} m²"
            except:
                val_surf = f"{raw_surf} m²" # إلا كان تكست، خليه كيف ما هو
        else:
            val_surf = "-"
        # --- BIDU (END) ---
        
        val_ref = str(feature[f_ref]) if f_ref in feature.fields().names() else "N/A"
        val_surf = f"{feature[f_surf]} m²" if f_surf in feature.fields().names() and feature[f_surf] else "-"
        val_comp = str(feature[f_comp]) if f_comp in feature.fields().names() and feature[f_comp] else "-"
        
        def add_row(lbl, val):
            l = QLabel(lbl); l.setProperty("class", "SubLabel")
            v = QLabel(val); v.setProperty("class", "Value")
            v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            info_layout.addRow(l, v)
            
        add_row("RÉFÉRENCE FONCIÈRE", val_ref)
        add_row("SUPERFICIE", val_surf)
        add_row("COMPLÉMENT", val_comp)
        layout.addWidget(info_card)

        # Geometry Card
        geo_card = QFrame(); geo_card.setObjectName("Card")
        geo_layout = QVBoxLayout(geo_card)
        h_geo = QHBoxLayout(); lbl_geo = QLabel("BORNES (XY)"); lbl_geo.setProperty("class", "Header")
        h_geo.addWidget(lbl_geo)
        btn_csv = QPushButton("CSV"); btn_csv.setIcon(Icons.get("csv")); btn_csv.setProperty("class", "BtnGhost")
        btn_csv.clicked.connect(self.export_coords_csv)
        h_geo.addWidget(btn_csv)
        geo_layout.addLayout(h_geo)
        
        self.coord_table = QTableWidget(); self.coord_table.setColumnCount(3)
        self.coord_table.setHorizontalHeaderLabels(["N°", "X", "Y"])
        self.coord_table.verticalHeader().setVisible(False)
        self.coord_table.setAlternatingRowColors(True)
        
        geom = feature.geometry(); self.vertices = []
        if geom.isMultipart():
             if len(geom.asMultiPolygon()) > 0: self.vertices = geom.asMultiPolygon()[0][0]
        else: self.vertices = geom.asPolygon()[0]
        
        self.coord_table.setRowCount(len(self.vertices))
        for i, p in enumerate(self.vertices):
            self.coord_table.setItem(i,0, QTableWidgetItem(str(i+1)))
            self.coord_table.setItem(i,1, QTableWidgetItem(f"{p.x():.2f}"))
            self.coord_table.setItem(i,2, QTableWidgetItem(f"{p.y():.2f}"))
        self.coord_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        geo_layout.addWidget(self.coord_table)
        layout.addWidget(geo_card)

        # Buttons
        btn_layout = QHBoxLayout()
        btn_plan = QPushButton(" GÉNÉRER PLAN"); btn_plan.setStyleSheet("background-color: #198754; color: white; border:none; padding:8px; border-radius:4px;")
        btn_plan.setIcon(Icons.get("pdf"))
        btn_plan.clicked.connect(self.generate_atlas_plan)
        
        btn_dxf = QPushButton(" EXPORT DXF"); btn_dxf.setStyleSheet("background-color: #fd7e14; color: white; border:none; padding:8px; border-radius:4px;")
        btn_dxf.setIcon(Icons.get("dxf"))
        btn_dxf.clicked.connect(self.export_geometry)
        
        btn_layout.addWidget(btn_plan); btn_layout.addWidget(btn_dxf)
        layout.addLayout(btn_layout)
        self.setLayout(layout)

    def export_coords_csv(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Export", "", "CSV (*.csv)")
        if filename:
            with open(filename, 'w', newline='') as f:
                writer = csv.writer(f, delimiter=';')
                writer.writerow(["ID", "X", "Y"])
                for i, p in enumerate(self.vertices): writer.writerow([i+1, p.x(), p.y()])

    def export_geometry(self):
        filename, _ = QFileDialog.getSaveFileName(self, "Export DXF", "", "DXF Files (*.dxf)")
        if filename:
            if not filename.lower().endswith('.dxf'): filename += '.dxf'
            crs = self.layer.crs().authid()
            temp = QgsVectorLayer(f"Polygon?crs={crs}", "export", "memory")
            dp = temp.dataProvider(); temp.startEditing()
            feat = QgsFeature(); feat.setGeometry(self.feature.geometry())
            dp.addFeatures([feat]); temp.commitChanges()
            
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "DXF"
            # Support QGIS versions
            try:
                QgsVectorFileWriter.writeAsVectorFormatV3(temp, filename, QgsProject.instance().transformContext(), options)
            except:
                QgsVectorFileWriter.writeAsVectorFormat(temp, filename, "utf-8", self.layer.crs(), "DXF")
                
            iface.messageBar().pushMessage("Succès", "DXF créé", level=1)

    def generate_atlas_plan(self):
        layout = QgsProject.instance().layoutManager().layoutByName("Fiche Parcelle")
        if layout:
            atlas = layout.atlas(); atlas.setEnabled(True)
            atlas.setCoverageLayer(self.layer)
            atlas.setFilterFeatures(True); atlas.setFilterExpression(f"$id = {self.feature.id()}")
            designer = iface.openLayoutDesigner(layout)
            if designer: designer.setAtlasPreviewEnabled(True); atlas.seekTo(0)
        else:
            QMessageBox.warning(self, "Erreur", "Layout 'Fiche Parcelle' introuvable")

# ==============================================================================
# CLASS 5: MAIN PLUGIN
# ==============================================================================
class CadgisSearchPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.settings = QgsSettings()

    def initGui(self):
        self.action_main = QAction(Icons.get("app_logo"), "CadGis Pro", self.iface.mainWindow())
        self.action_main.triggered.connect(self.run)
        
        self.action_config = QAction(Icons.get("settings"), "Configuration", self.iface.mainWindow())
        self.action_config.triggered.connect(self.open_config)
        
        self.iface.addPluginToMenu("&CadGis Pro", self.action_main)
        self.iface.addPluginToMenu("&CadGis Pro", self.action_config)
        
        self.toolbar = self.iface.addToolBar("CadGis Toolbar")
        self.toolbar.setObjectName("CadGisToolbar")
        self.toolbar.addAction(self.action_main)

    def unload(self):
        try:
            self.iface.removePluginMenu("&CadGis Pro", self.action_main)
            self.iface.removePluginMenu("&CadGis Pro", self.action_config)
            del self.toolbar
        except: pass
        if self.dock: self.iface.removeDockWidget(self.dock)

    def open_config(self):
        dlg = CadgisConfigDialog(self.iface.mainWindow())
        dlg.exec_()

    # --- UI DOCK ---
    def create_dock_ui(self):
        self.dock = QDockWidget("Recherche Cadastrale", self.iface.mainWindow())
        self.dock.setObjectName("CadGisDock")
        contents = QWidget(); contents.setStyleSheet(MODERN_STYLE)
        
        main_layout = QVBoxLayout(contents)
        main_layout.setContentsMargins(10, 10, 10, 10)
        
        # Search Bar
        search_line = QHBoxLayout()
        self.nature_cb = QComboBox(); self.nature_cb.addItems(["", "T", "R", "N"]); self.nature_cb.setFixedWidth(50)
        self.num_input = QLineEdit(); self.num_input.setPlaceholderText("Num...")
        self.ind_input = QLineEdit(); self.ind_input.setPlaceholderText("Ind"); self.ind_input.setFixedWidth(40)
        self.comp_input = QLineEdit(); self.comp_input.setPlaceholderText("Complément"); self.comp_input.setFixedWidth(80)
        
        btn_search = QPushButton(""); btn_search.setObjectName("BtnPrimary")
        btn_search.setIcon(Icons.get("search"))
        btn_search.setFixedWidth(40)
        btn_search.clicked.connect(self.exec_search)
        
        search_line.addWidget(self.nature_cb)
        search_line.addWidget(self.num_input, 1)
        search_line.addWidget(self.ind_input)
        search_line.addWidget(self.comp_input)
        search_line.addWidget(btn_search)
        main_layout.addLayout(search_line)
        
        # Table
        self.results_table = QTableWidget(); self.results_table.setColumnCount(3)
        self.results_table.setHorizontalHeaderLabels(["RÉF", "Complément", "SURF"])
        self.results_table.verticalHeader().setVisible(False)
        self.results_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.results_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.results_table.setAlternatingRowColors(True)
        
        # CHANGEMENT: itemClicked au lieu de itemDoubleClicked
        self.results_table.itemClicked.connect(self.zoom_and_popup)
        
        h = self.results_table.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.Stretch)
        
        main_layout.addWidget(self.results_table)
        
        # Config Shortcut
        btn_conf = QPushButton("Configuration"); btn_conf.setProperty("class", "BtnGhost")
        btn_conf.clicked.connect(self.open_config)
        main_layout.addWidget(btn_conf)
        
        self.dock.setWidget(contents)

    def run(self):
        if not self.dock:
            self.create_dock_ui()
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dock)
        self.dock.show()

    def exec_search(self):
        self.results_table.setRowCount(0)
        
        # 1. RECUPERATION DE LA COUCHE
        saved_layer_name = self.settings.value("Cadgis/target_layer_name", "")
        layers = QgsProject.instance().mapLayersByName(saved_layer_name)
        
        if layers:
            self.current_layer = layers[0]
        else:
            if self.iface.activeLayer() and self.iface.activeLayer().type() == QgsVectorLayer.VectorLayer:
                self.current_layer = self.iface.activeLayer()
            else:
                iface.messageBar().pushMessage("Attention", "Veuillez configurer la couche cible.", level=2)
                self.open_config()
                return

        # 2. RECUPERATION DES CHAMPS
        f_nat = self.settings.value("Cadgis/fields/nature", "")
        f_num = self.settings.value("Cadgis/fields/num", "")
        f_ind = self.settings.value("Cadgis/fields/indice", "")
        f_comp = self.settings.value("Cadgis/fields/complement", "")
        f_ref = self.settings.value("Cadgis/fields/ref_fonc", "")
        f_surf = self.settings.value("Cadgis/fields/surf_adop", "")
        
        if not f_num: 
            iface.messageBar().pushMessage("Config", "Champs non configurés.", level=2)
            return

        # 3. CONSTRUCTION REQUETE
        parts = []
        if self.nature_cb.currentText(): 
            parts.append(f"\"{f_nat}\" = '{self.nature_cb.currentText()}'")
        
        if self.num_input.text():
            val = self.num_input.text()
            term = f"\"{f_num}\" = {val}" if val.isdigit() else f"\"{f_num}\" = '{val}'"
            parts.append(term)
            
        if self.ind_input.text():
            parts.append(f"\"{f_ind}\" = '{self.ind_input.text()}'")
            
        if self.comp_input.text():
            parts.append(f"\"{f_comp}\" ILIKE '%{self.comp_input.text()}%'")
        
        if not parts: return
        expr = " AND ".join(parts)

        try:
            req = QgsFeatureRequest().setFilterExpression(expr)
            features = list(self.current_layer.getFeatures(req))
        except:
            iface.messageBar().pushMessage("Erreur", "Recherche échouée. Vérifiez les champs.", level=2)
            return

        self.results_table.setRowCount(len(features))
        for i, f in enumerate(features):
            ref_val = str(f[f_ref]) if f_ref in f.fields().names() and f[f_ref] else "N/A"
            comp_val = str(f[f_comp]) if f_comp in f.fields().names() and f[f_comp] else ""
            #surf_val = f"{f[f_surf]}" if f_surf in f.fields().names() and f[f_surf] else ""
            
            # ... (داخل exec_search Loop)
        for i, f in enumerate(features):
            ref_val = str(f[f_ref]) if f_ref in f.fields().names() and f[f_ref] else "N/A"
            comp_val = str(f[f_comp]) if f_comp in f.fields().names() and f[f_comp] else ""
            
            # --- BIDU (START) ---
            raw_s = f[f_surf] if f_surf in f.fields().names() else None
            if raw_s:
                try:
                    surf_val = f"{float(raw_s):.2f}" # جوج أرقام بعد الفاصلة
                except:
                    surf_val = str(raw_s)
            else:
                surf_val = ""
            # --- BIDU (END) ---

            
            # ... (باقي الكود)
            
            self.results_table.setItem(i, 0, QTableWidgetItem(ref_val))
            self.results_table.setItem(i, 1, QTableWidgetItem(comp_val))
            self.results_table.setItem(i, 2, QTableWidgetItem(surf_val))
            self.results_table.item(i, 0).setData(Qt.UserRole, f.id())

    def zoom_and_popup(self, item):
        row = item.row()
        fid = self.results_table.item(row, 0).data(Qt.UserRole)
        f = self.current_layer.getFeature(fid)
        
        # ZOOM FIX
        self.current_layer.removeSelection()
        self.current_layer.select(fid)
        self.iface.mapCanvas().zoomToSelected(self.current_layer) # Methode Native plus robuste
        self.iface.mapCanvas().refresh()
        
        if hasattr(self, 'current_dialog') and self.current_dialog:
            self.current_dialog.close()
        self.current_dialog = ParcelInfoDialog(f, self.current_layer, self.iface.mainWindow())
        self.current_dialog.show()